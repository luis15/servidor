<?php
	define('DB_USERNAME','u979108798_usu');
	define('DB_PASSWORD','server123');
	define('DB_NAME','u979108798_bd');
	define('DB_HOST','mysql.hostinger.com.br');

	define('FIREBASE_API_KEY', 'AIzaSyB3SX--a9w7hmEmkC8ohY1MZ-SudEUTbTk
');
